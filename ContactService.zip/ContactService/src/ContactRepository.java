/* Carter Williams
 * Southern New Hampshire University - CS-499
 * ContactService Enhancement Project
 * 28 July 2025
 */
package com.contactservice.repository;

import com.contactservice.model.Contact;
import org.springframework.stereotype.Repository;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;

@Repository
public class ContactRepository {
    
    @Autowired
    private DataSource dataSource;
    
    // Create contacts table if it doesn't exist
    public void initializeDatabase() {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS contacts (" +
            "id VARCHAR(10) PRIMARY KEY, " +
            "first_name VARCHAR(10) NOT NULL, " +
            "last_name VARCHAR(10) NOT NULL, " +
            "phone_number VARCHAR(10) NOT NULL, " +
            "home_address VARCHAR(30) NOT NULL, " +
            "created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
            "modified_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP" +
            ")";
        
        String createIndexSQL = "CREATE INDEX IF NOT EXISTS idx_phone ON contacts(phone_number)";
        
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(createTableSQL);
            stmt.execute(createIndexSQL);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to initialize database", e);
        }
    }
    
    public Contact save(Contact contact) {
        String sql = "INSERT INTO contacts (id, first_name, last_name, phone_number, home_address) " +
            "VALUES (?, ?, ?, ?, ?) " +
            "ON DUPLICATE KEY UPDATE " +
            "first_name = VALUES(first_name), " +
            "last_name = VALUES(last_name), " +
            "phone_number = VALUES(phone_number), " +
            "home_address = VALUES(home_address)";
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, contact.getId());
            pstmt.setString(2, contact.getFirstName());
            pstmt.setString(3, contact.getLastName());
            pstmt.setString(4, contact.getPhoneNumber());
            pstmt.setString(5, contact.getHomeAddress());
            
            pstmt.executeUpdate();
            return contact;
            
        } catch (SQLException e) {
            throw new RuntimeException("Failed to save contact", e);
        }
    }
    
    public Contact findById(String id) {
        String sql = "SELECT * FROM contacts WHERE id = ?";
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return mapResultSetToContact(rs);
            }
            return null;
            
        } catch (SQLException e) {
            throw new RuntimeException("Failed to find contact by ID", e);
        }
    }
    
    public List<Contact> findAll() {
        String sql = "SELECT * FROM contacts ORDER BY id";
        List<Contact> contacts = new ArrayList<>();
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                contacts.add(mapResultSetToContact(rs));
            }
            
        } catch (SQLException e) {
            throw new RuntimeException("Failed to retrieve all contacts", e);
        }
        
        return contacts;
    }
    
    public Contact findByPhoneNumber(String phoneNumber) {
        String sql = "SELECT * FROM contacts WHERE phone_number = ?";
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, phoneNumber);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return mapResultSetToContact(rs);
            }
            return null;
            
        } catch (SQLException e) {
            throw new RuntimeException("Failed to find contact by phone", e);
        }
    }
    
    public List<Contact> findByNamePrefix(String prefix) {
        String sql = "SELECT * FROM contacts " +
            "WHERE first_name LIKE ? OR last_name LIKE ? " +
            "ORDER BY first_name, last_name";
        List<Contact> contacts = new ArrayList<>();
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            String searchPattern = prefix + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                contacts.add(mapResultSetToContact(rs));
            }
            
        } catch (SQLException e) {
            throw new RuntimeException("Failed to search contacts by name", e);
        }
        
        return contacts;
    }
    
    public void deleteById(String id) {
        String sql = "DELETE FROM contacts WHERE id = ?";
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, id);
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected == 0) {
                throw new IllegalArgumentException("Contact ID not found");
            }
            
        } catch (SQLException e) {
            throw new RuntimeException("Failed to delete contact", e);
        }
    }
    
    // Analytics method for contact statistics
    public int getContactCount() {
        String sql = "SELECT COUNT(*) FROM contacts";
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            if (rs.next()) {
                return rs.getInt(1);
            }
            return 0;
            
        } catch (SQLException e) {
            throw new RuntimeException("Failed to get contact count", e);
        }
    }
    
    private Contact mapResultSetToContact(ResultSet rs) throws SQLException {
        return new Contact(
            rs.getString("id"),
            rs.getString("first_name"),
            rs.getString("last_name"),
            rs.getString("phone_number"),
            rs.getString("home_address")
        );
    }
}