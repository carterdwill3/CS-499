/* Carter Williams
 * Southern New Hampshire University - CS-499
 * ContactService Enhancement Project
 * 28 July 2025
 */
package com.contactservice.service;

import com.contactservice.model.Contact;
import com.contactservice.repository.ContactRepository;
import com.contactservice.datastructures.ContactBinarySearchTree;
import com.contactservice.algorithms.ContactSortingAlgorithms;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;

@Service
public class ContactService {
    @Autowired
    private ContactRepository contactRepository;
    
    // Keep in-memory structures for performance
    private final Map<String, Contact> contactCache = new HashMap<>();
    private final ContactBinarySearchTree binarySearchTree = new ContactBinarySearchTree();
    private final Map<String, String> phoneToIdMap = new HashMap<>();

    public Contact addContact(Contact contact) {
        // Check if contact already exists in database
        Contact existingContact = contactRepository.findById(contact.getId());
        if (existingContact != null) {
            throw new IllegalArgumentException("Contact ID already exists.");
        }
        
        // Save to database
        Contact savedContact = contactRepository.save(contact);
        
        // Update in-memory structures
        contactCache.put(contact.getId(), savedContact);
        binarySearchTree.insert(savedContact);
        phoneToIdMap.put(contact.getPhoneNumber(), contact.getId());
        
        return savedContact;
    }

    public void removeContact(String id) {
        Contact contact = contactRepository.findById(id);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        
        // Remove from database
        contactRepository.deleteById(id);
        
        // Update in-memory structures
        contactCache.remove(id);
        binarySearchTree.delete(id);
        phoneToIdMap.remove(contact.getPhoneNumber());
    }

    public void modifyContact(String id, String firstName, String lastName, String phoneNumber, String homeAddress) {
        Contact contact = contactRepository.findById(id);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        
        // Update phone mapping if phone number changes
        if (phoneNumber != null && !phoneNumber.equals(contact.getPhoneNumber())) {
            phoneToIdMap.remove(contact.getPhoneNumber());
            phoneToIdMap.put(phoneNumber, id);
        }
        
        // Update contact object
        if (firstName != null) contact.updateFirstName(firstName);
        if (lastName != null) contact.updateLastName(lastName);
        if (phoneNumber != null) contact.updatePhoneNumber(phoneNumber);
        if (homeAddress != null) contact.updateHomeAddress(homeAddress);
        
        // Save to database
        contactRepository.save(contact);
        
        // Update cache
        contactCache.put(id, contact);
    }

    public Contact findContact(String id) {
        // Try cache first for performance
        Contact cachedContact = contactCache.get(id);
        if (cachedContact != null) {
            return cachedContact;
        }
        
        // Fallback to database
        Contact contact = contactRepository.findById(id);
        if (contact != null) {
            contactCache.put(id, contact);
        }
        return contact;
    }
    
    // Enhanced search using binary search tree
    public Contact findContactBST(String id) {
        return binarySearchTree.search(id);
    }
    
    // Search contact by phone number using database
    public Contact findContactByPhone(String phoneNumber) {
        return contactRepository.findByPhoneNumber(phoneNumber);
    }

    public List<Contact> getAllContacts() {
        return contactRepository.findAll();
    }
    
    // Get contacts sorted by different criteria
    public List<Contact> getContactsSorted(String sortBy) {
        List<Contact> contacts = contactRepository.findAll();
        
        switch (sortBy.toLowerCase()) {
            case "firstname":
                ContactSortingAlgorithms.quickSort(contacts, ContactSortingAlgorithms.ContactComparators.BY_FIRST_NAME);
                break;
            case "lastname":
                ContactSortingAlgorithms.mergeSort(contacts, ContactSortingAlgorithms.ContactComparators.BY_LAST_NAME);
                break;
            case "phone":
                ContactSortingAlgorithms.quickSort(contacts, ContactSortingAlgorithms.ContactComparators.BY_PHONE);
                break;
            default:
                ContactSortingAlgorithms.quickSort(contacts, ContactSortingAlgorithms.ContactComparators.BY_ID);
        }
        
        return contacts;
    }
    
    // Binary search on sorted contacts
    public Contact binarySearchContact(String searchId) {
        List<Contact> sortedContacts = getContactsSorted("id");
        return ContactSortingAlgorithms.binarySearch(sortedContacts, searchId);
    }
    
    // Auto-complete functionality using database
    public List<Contact> searchContactsByNamePrefix(String prefix) {
        return contactRepository.findByNamePrefix(prefix);
    }
    
    // Database analytics method
    public Map<String, Object> getContactAnalytics() {
        Map<String, Object> analytics = new HashMap<>();
        analytics.put("totalContacts", contactRepository.getContactCount());
        
        List<Contact> allContacts = contactRepository.findAll();
        
        // Calculate some basic statistics
        long uniquePhonePrefixes = allContacts.stream()
            .map(c -> c.getPhoneNumber().substring(0, 3))
            .distinct()
            .count();
        
        analytics.put("uniqueAreaCodes", uniquePhonePrefixes);
        analytics.put("averageNameLength", 
            allContacts.stream()
                .mapToInt(c -> c.getFirstName().length() + c.getLastName().length())
                .average()
                .orElse(0.0));
        
        return analytics;
    }
}

@RestController
@RequestMapping("/api/contacts")
class ContactController {
    @Autowired
    private ContactService contactService;

    @GetMapping
    public ResponseEntity<List<Contact>> getAllContacts(@RequestParam(required = false) String sortBy) {
        try {
            List<Contact> contacts;
            if (sortBy != null && !sortBy.isEmpty()) {
                contacts = contactService.getContactsSorted(sortBy);
            } else {
                contacts = contactService.getAllContacts();
            }
            return ResponseEntity.ok(contacts);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Contact> getContactById(@PathVariable String id) {
        try {
            Contact contact = contactService.findContact(id);
            if (contact != null) {
                return ResponseEntity.ok(contact);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @GetMapping("/search/phone/{phoneNumber}")
    public ResponseEntity<Contact> getContactByPhone(@PathVariable String phoneNumber) {
        try {
            Contact contact = contactService.findContactByPhone(phoneNumber);
            if (contact != null) {
                return ResponseEntity.ok(contact);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @GetMapping("/search/name/{prefix}")
    public ResponseEntity<List<Contact>> searchContactsByName(@PathVariable String prefix) {
        try {
            List<Contact> contacts = contactService.searchContactsByNamePrefix(prefix);
            return ResponseEntity.ok(contacts);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @GetMapping("/analytics")
    public ResponseEntity<Map<String, Object>> getAnalytics() {
        try {
            Map<String, Object> analytics = contactService.getContactAnalytics();
            return ResponseEntity.ok(analytics);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping
    public ResponseEntity<Contact> createContact(@RequestBody Contact contact) {
        try {
            Contact createdContact = contactService.addContact(contact);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdContact);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Contact> updateContact(@PathVariable String id, @RequestBody Contact request) {
        try {
            contactService.modifyContact(id, 
                request.getFirstName(), 
                request.getLastName(), 
                request.getPhoneNumber(), 
                request.getHomeAddress());
            Contact updatedContact = contactService.findContact(id);
            return ResponseEntity.ok(updatedContact);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteContact(@PathVariable String id) {
        try {
            contactService.removeContact(id);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}