/* Carter Williams
 * Southern New Hampshire University - CS-499
 * ContactService Enhancement Project
 * 9 July 2025
 */
package com.contactservice.service;

import com.contactservice.model.Contact;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

@Service
public class ContactService {
    private final Map<String, Contact> contactList = new HashMap<>();

    public Contact addContact(Contact contact) {
        if (contactList.containsKey(contact.getId())) {
            throw new IllegalArgumentException("Contact ID already exists.");
        }
        contactList.put(contact.getId(), contact);
        return contact;
    }

    public void removeContact(String id) {
        if (!contactList.containsKey(id)) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        contactList.remove(id);
    }

    public void modifyContact(String id, String firstName, String lastName, String phoneNumber, String homeAddress) {
        Contact contact = contactList.get(id);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        if (firstName != null) contact.updateFirstName(firstName);
        if (lastName != null) contact.updateLastName(lastName);
        if (phoneNumber != null) contact.updatePhoneNumber(phoneNumber);
        if (homeAddress != null) contact.updateHomeAddress(homeAddress);
    }

    public Contact findContact(String id) {
        return contactList.get(id);
    }

    public List<Contact> getAllContacts() {
        return new ArrayList<>(contactList.values());
    }
}

@RestController
@RequestMapping("/api/contacts")
class ContactController {
    @Autowired
    private ContactService contactService;

    @GetMapping
    public ResponseEntity<List<Contact>> getAllContacts() {
        try {
            List<Contact> contacts = contactService.getAllContacts();
            return ResponseEntity.ok(contacts);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Contact> getContactById(@PathVariable String id) {
        try {
            Contact contact = contactService.findContact(id);
            if (contact != null) {
                return ResponseEntity.ok(contact);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping
    public ResponseEntity<Contact> createContact(@RequestBody Contact contact) {
        try {
            Contact createdContact = contactService.addContact(contact);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdContact);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Contact> updateContact(@PathVariable String id, @RequestBody Contact request) {
        try {
            contactService.modifyContact(id, 
                request.getFirstName(), 
                request.getLastName(), 
                request.getPhoneNumber(), 
                request.getHomeAddress());
            Contact updatedContact = contactService.findContact(id);
            return ResponseEntity.ok(updatedContact);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteContact(@PathVariable String id) {
        try {
            contactService.removeContact(id);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}