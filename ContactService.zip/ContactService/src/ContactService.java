/* Carter Williams
 * Southern New Hampshire University - CS-499
 * ContactService Enhancement Project
 * 19 July 2025
 */
package com.contactservice.service;

import com.contactservice.model.Contact;
import com.contactservice.datastructures.ContactBinarySearchTree;
import com.contactservice.algorithms.ContactSortingAlgorithms;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;

@Service
public class ContactService {
    private final Map<String, Contact> contactList = new HashMap<>();
    private final ContactBinarySearchTree binarySearchTree = new ContactBinarySearchTree();
    
    // Hash table for phone number indexing
    private final Map<String, String> phoneToIdMap = new HashMap<>();

    public Contact addContact(Contact contact) {
        if (contactList.containsKey(contact.getId())) {
            throw new IllegalArgumentException("Contact ID already exists.");
        }
        contactList.put(contact.getId(), contact);
        binarySearchTree.insert(contact);
        phoneToIdMap.put(contact.getPhoneNumber(), contact.getId());
        return contact;
    }

    public void removeContact(String id) {
        Contact contact = contactList.get(id);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        contactList.remove(id);
        binarySearchTree.delete(id);
        phoneToIdMap.remove(contact.getPhoneNumber());
    }

    public void modifyContact(String id, String firstName, String lastName, String phoneNumber, String homeAddress) {
        Contact contact = contactList.get(id);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        
        // Update phone mapping if phone number changes
        if (phoneNumber != null && !phoneNumber.equals(contact.getPhoneNumber())) {
            phoneToIdMap.remove(contact.getPhoneNumber());
            phoneToIdMap.put(phoneNumber, id);
        }
        
        if (firstName != null) contact.updateFirstName(firstName);
        if (lastName != null) contact.updateLastName(lastName);
        if (phoneNumber != null) contact.updatePhoneNumber(phoneNumber);
        if (homeAddress != null) contact.updateHomeAddress(homeAddress);
    }

    public Contact findContact(String id) {
        return contactList.get(id);
    }
    
    // Enhanced search using binary search tree
    public Contact findContactBST(String id) {
        return binarySearchTree.search(id);
    }
    
    // Search contact by phone number using hash table
    public Contact findContactByPhone(String phoneNumber) {
        String id = phoneToIdMap.get(phoneNumber);
        return id != null ? contactList.get(id) : null;
    }

    public List<Contact> getAllContacts() {
        return new ArrayList<>(contactList.values());
    }
    
    // Get contacts sorted by different criteria
    public List<Contact> getContactsSorted(String sortBy) {
        List<Contact> contacts = new ArrayList<>(contactList.values());
        
        switch (sortBy.toLowerCase()) {
            case "firstname":
                ContactSortingAlgorithms.quickSort(contacts, ContactSortingAlgorithms.ContactComparators.BY_FIRST_NAME);
                break;
            case "lastname":
                ContactSortingAlgorithms.mergeSort(contacts, ContactSortingAlgorithms.ContactComparators.BY_LAST_NAME);
                break;
            case "phone":
                ContactSortingAlgorithms.quickSort(contacts, ContactSortingAlgorithms.ContactComparators.BY_PHONE);
                break;
            default:
                ContactSortingAlgorithms.quickSort(contacts, ContactSortingAlgorithms.ContactComparators.BY_ID);
        }
        
        return contacts;
    }
    
    // Binary search on sorted contacts
    public Contact binarySearchContact(String searchId) {
        List<Contact> sortedContacts = getContactsSorted("id");
        return ContactSortingAlgorithms.binarySearch(sortedContacts, searchId);
    }
    
    // Auto-complete functionality for names
    public List<Contact> searchContactsByNamePrefix(String prefix) {
        return contactList.values().stream()
            .filter(contact -> 
                contact.getFirstName().toLowerCase().startsWith(prefix.toLowerCase()) ||
                contact.getLastName().toLowerCase().startsWith(prefix.toLowerCase()))
            .collect(Collectors.toList());
    }
}

@RestController
@RequestMapping("/api/contacts")
class ContactController {
    @Autowired
    private ContactService contactService;

    @GetMapping
    public ResponseEntity<List<Contact>> getAllContacts(@RequestParam(required = false) String sortBy) {
        try {
            List<Contact> contacts;
            if (sortBy != null && !sortBy.isEmpty()) {
                contacts = contactService.getContactsSorted(sortBy);
            } else {
                contacts = contactService.getAllContacts();
            }
            return ResponseEntity.ok(contacts);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Contact> getContactById(@PathVariable String id) {
        try {
            Contact contact = contactService.findContactBST(id);
            if (contact != null) {
                return ResponseEntity.ok(contact);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @GetMapping("/search/phone/{phoneNumber}")
    public ResponseEntity<Contact> getContactByPhone(@PathVariable String phoneNumber) {
        try {
            Contact contact = contactService.findContactByPhone(phoneNumber);
            if (contact != null) {
                return ResponseEntity.ok(contact);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @GetMapping("/search/name/{prefix}")
    public ResponseEntity<List<Contact>> searchContactsByName(@PathVariable String prefix) {
        try {
            List<Contact> contacts = contactService.searchContactsByNamePrefix(prefix);
            return ResponseEntity.ok(contacts);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping
    public ResponseEntity<Contact> createContact(@RequestBody Contact contact) {
        try {
            Contact createdContact = contactService.addContact(contact);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdContact);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Contact> updateContact(@PathVariable String id, @RequestBody Contact request) {
        try {
            contactService.modifyContact(id, 
                request.getFirstName(), 
                request.getLastName(), 
                request.getPhoneNumber(), 
                request.getHomeAddress());
            Contact updatedContact = contactService.findContact(id);
            return ResponseEntity.ok(updatedContact);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteContact(@PathVariable String id) {
        try {
            contactService.removeContact(id);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}