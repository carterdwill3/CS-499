/* Carter Williams
 * Southern New Hampshire University - CS-499
 * ContactService Enhancement Project
 * 30 July 2025
 */
package com.contactservice.config;

import com.contactservice.repository.ContactRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

@Configuration
public class DatabaseConfig {
    
    @Autowired
    private ContactRepository contactRepository;
    
    @Bean
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        
        // Using H2 in-memory database for simplicity
        dataSource.setDriverClassName("org.h2.Driver");
        dataSource.setUrl("jdbc:h2:mem:contactdb;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE");
        dataSource.setUsername("sa");
        dataSource.setPassword("");
        
        return dataSource;
    }
    
    @PostConstruct
    public void initializeData() {
        // Initialize database tables
        contactRepository.initializeDatabase();
    }
}