/* Carter Williams
 * Southern New Hampshire University - CS-499
 * ContactService Enhancement Project
 * 19 July 2025
 */
package com.contactservice.datastructures;

import com.contactservice.model.Contact;
import java.util.ArrayList;
import java.util.List;

public class ContactBinarySearchTree {
    private TreeNode root;
    
    private class TreeNode {
        Contact contact;
        TreeNode left;
        TreeNode right;
        
        TreeNode(Contact contact) {
            this.contact = contact;
        }
    }
    
    public void insert(Contact contact) {
        root = insertRec(root, contact);
    }
    
    private TreeNode insertRec(TreeNode root, Contact contact) {
        if (root == null) {
            return new TreeNode(contact);
        }
        
        if (contact.getId().compareTo(root.contact.getId()) < 0) {
            root.left = insertRec(root.left, contact);
        } else if (contact.getId().compareTo(root.contact.getId()) > 0) {
            root.right = insertRec(root.right, contact);
        }
        
        return root;
    }
    
    public Contact search(String id) {
        return searchRec(root, id);
    }
    
    private Contact searchRec(TreeNode root, String id) {
        if (root == null || root.contact.getId().equals(id)) {
            return root != null ? root.contact : null;
        }
        
        if (id.compareTo(root.contact.getId()) < 0) {
            return searchRec(root.left, id);
        }
        
        return searchRec(root.right, id);
    }
    
    public List<Contact> inOrderTraversal() {
        List<Contact> result = new ArrayList<>();
        inOrderRec(root, result);
        return result;
    }
    
    private void inOrderRec(TreeNode root, List<Contact> result) {
        if (root != null) {
            inOrderRec(root.left, result);
            result.add(root.contact);
            inOrderRec(root.right, result);
        }
    }
    
    public void delete(String id) {
        root = deleteRec(root, id);
    }
    
    private TreeNode deleteRec(TreeNode root, String id) {
        if (root == null) return root;
        
        if (id.compareTo(root.contact.getId()) < 0) {
            root.left = deleteRec(root.left, id);
        } else if (id.compareTo(root.contact.getId()) > 0) {
            root.right = deleteRec(root.right, id);
        } else {
            if (root.left == null) return root.right;
            else if (root.right == null) return root.left;
            
            root.contact = minValue(root.right);
            root.right = deleteRec(root.right, root.contact.getId());
        }
        
        return root;
    }
    
    private Contact minValue(TreeNode root) {
        Contact minv = root.contact;
        while (root.left != null) {
            minv = root.left.contact;
            root = root.left;
        }
        return minv;
    }
}