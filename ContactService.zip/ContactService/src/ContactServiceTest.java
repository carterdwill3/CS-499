/* Carter Williams
 * Southern New Hampshire University - CS-499
 * ContactService Enhancement Project
 * 10 July 2025
 */
import com.contactservice.model.Contact;
import com.contactservice.service.ContactService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.beans.factory.annotation.Autowired;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class ContactServiceTest {
    
    @Autowired
    private ContactService service;

    @BeforeEach
    public void setup() {
        // Clear in-memory storage before each test
        service.getAllContacts().forEach(contact -> 
            service.removeContact(contact.getId()));
    }

    @Test
    public void shouldAddContactSuccessfully() {
        Contact contact = new Contact("C300456", "Charlie", "Bucket", "1029384756", "404 Capitol Ave");
        Contact savedContact = service.addContact(contact);
        assertEquals(contact.getId(), savedContact.getId());
        assertEquals(contact, service.findContact("C300456"));
    }

    @Test
    public void shouldThrowErrorOnDuplicateContactAddition() {
        Contact contact = new Contact("C300456", "Charlie", "Bucket", "1029384756", "404 Capitol Ave");
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact));
    }

    @Test
    public void shouldRemoveContactSuccessfully() {
        Contact contact = new Contact("C300456", "Charlie", "Bucket", "1029384756", "404 Capitol Ave");
        service.addContact(contact);
        service.removeContact("C300456");
        assertNull(service.findContact("C300456"));
    }

    @Test
    public void shouldModifyContactSuccessfully() {
        Contact contact = new Contact("C300456", "Charlie", "Bucket", "1029384756", "404 Capitol Ave");
        service.addContact(contact);
        service.modifyContact("C300456", "Charles", null, null, "414 Douglas Blvd");
        assertEquals("Charles", service.findContact("C300456").getFirstName());
        assertEquals("414 Douglas Blvd", service.findContact("C300456").getHomeAddress());
    }

    @Test
    public void shouldThrowErrorWhenUpdatingNonExistentContact() {
        assertThrows(IllegalArgumentException.class, () -> 
            service.modifyContact("NonExistentID", "Charles", null, null, "414 Douglas Blvd"));
    }

    @Test
    public void shouldGetAllContactsSuccessfully() {
        Contact contact1 = new Contact("C300456", "Charlie", "Bucket", "1029384756", "404 Capitol Ave");
        Contact contact2 = new Contact("C300457", "John", "Doe", "5551234567", "123 Main St");
        service.addContact(contact1);
        service.addContact(contact2);
        assertEquals(2, service.getAllContacts().size());
    }
}