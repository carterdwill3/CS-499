/* Carter Williams
 * Southern New Hampshire University - CS-499
 * ContactService Enhancement Project
 * 21 July 2025
 */
package com.contactservice.algorithms;

import com.contactservice.model.Contact;
import java.util.List;
import java.util.Comparator;

public class ContactSortingAlgorithms {
    
    // QuickSort implementation for contacts
    public static void quickSort(List<Contact> contacts, Comparator<Contact> comparator) {
        quickSortHelper(contacts, 0, contacts.size() - 1, comparator);
    }
    
    private static void quickSortHelper(List<Contact> contacts, int low, int high, Comparator<Contact> comparator) {
        if (low < high) {
            int pi = partition(contacts, low, high, comparator);
            quickSortHelper(contacts, low, pi - 1, comparator);
            quickSortHelper(contacts, pi + 1, high, comparator);
        }
    }
    
    private static int partition(List<Contact> contacts, int low, int high, Comparator<Contact> comparator) {
        Contact pivot = contacts.get(high);
        int i = (low - 1);
        
        for (int j = low; j < high; j++) {
            if (comparator.compare(contacts.get(j), pivot) <= 0) {
                i++;
                swap(contacts, i, j);
            }
        }
        swap(contacts, i + 1, high);
        return i + 1;
    }
    
    // MergeSort implementation for contacts
    public static void mergeSort(List<Contact> contacts, Comparator<Contact> comparator) {
        if (contacts.size() > 1) {
            mergeSortHelper(contacts, 0, contacts.size() - 1, comparator);
        }
    }
    
    private static void mergeSortHelper(List<Contact> contacts, int left, int right, Comparator<Contact> comparator) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            mergeSortHelper(contacts, left, mid, comparator);
            mergeSortHelper(contacts, mid + 1, right, comparator);
            merge(contacts, left, mid, right, comparator);
        }
    }
    
    private static void merge(List<Contact> contacts, int left, int mid, int right, Comparator<Contact> comparator) {
        // Create temp arrays
        int n1 = mid - left + 1;
        int n2 = right - mid;
        
        Contact[] leftArray = new Contact[n1];
        Contact[] rightArray = new Contact[n2];
        
        for (int i = 0; i < n1; i++)
            leftArray[i] = contacts.get(left + i);
        for (int j = 0; j < n2; j++)
            rightArray[j] = contacts.get(mid + 1 + j);
        
        int i = 0, j = 0, k = left;
        
        while (i < n1 && j < n2) {
            if (comparator.compare(leftArray[i], rightArray[j]) <= 0) {
                contacts.set(k, leftArray[i]);
                i++;
            } else {
                contacts.set(k, rightArray[j]);
                j++;
            }
            k++;
        }
        
        while (i < n1) {
            contacts.set(k, leftArray[i]);
            i++;
            k++;
        }
        
        while (j < n2) {
            contacts.set(k, rightArray[j]);
            j++;
            k++;
        }
    }
    
    private static void swap(List<Contact> contacts, int i, int j) {
        Contact temp = contacts.get(i);
        contacts.set(i, contacts.get(j));
        contacts.set(j, temp);
    }
    
    // Binary search for sorted contact list
    public static Contact binarySearch(List<Contact> sortedContacts, String searchId) {
        int left = 0;
        int right = sortedContacts.size() - 1;
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            String midId = sortedContacts.get(mid).getId();
            
            int comparison = midId.compareTo(searchId);
            if (comparison == 0) {
                return sortedContacts.get(mid);
            }
            
            if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        
        return null;
    }
    
    // Custom comparators for different sorting criteria
    public static class ContactComparators {
        public static final Comparator<Contact> BY_ID = 
            Comparator.comparing(Contact::getId);
        
        public static final Comparator<Contact> BY_FIRST_NAME = 
            Comparator.comparing(Contact::getFirstName);
        
        public static final Comparator<Contact> BY_LAST_NAME = 
            Comparator.comparing(Contact::getLastName);
        
        public static final Comparator<Contact> BY_PHONE = 
            Comparator.comparing(Contact::getPhoneNumber);
    }
}