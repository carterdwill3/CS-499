CS-499 - ContactService: ENHANCEMENT1

3-2 Milestone